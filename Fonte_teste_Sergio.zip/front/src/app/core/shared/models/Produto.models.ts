export interface Produto  {
    IdProd: number
    NomProd: String
    VlVend: number
    DescProd: String,
    StrImag: string,
    DtInclusao: String
}