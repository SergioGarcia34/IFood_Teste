import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-error-auth',
  templateUrl: './error-auth.component.html',
  styleUrls: ['./error-auth.component.scss']
})
export class ErrorAuthComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
